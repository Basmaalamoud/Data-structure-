package com.basma;

public class WordInformation {
    public String word;
    public int size;
    public LinkedList<WordOccurrence> loc = new LinkedList<>();

    public WordInformation(String word, int row, int col){
        this.word=word;
        size =1;
        loc.insert(new WordOccurrence(row,col));
    }
}




