package com.basma;

public class LinkedList<T> {
    public Node<T> head;
    public Node<T> current;
    private int size;

    public LinkedList(LinkedList<T> loc) {
        if(loc.head==null) return;
        Node<T> tmp = loc.head;
        while(tmp!=null){
            this.insert(tmp.data);
            tmp=tmp.next;
        }
    }
    public LinkedList() {
        current = head = null;
        size=0;
    }

    public void insert(T data){
        Node<T> newNode = new Node<>(data);
        size++;
        if(head==null) head = newNode;
        else{
            Node<T> tmp = head;
            while(tmp.next!=null) tmp=tmp.next;
            tmp.next = newNode;
        }
    }
    public Node<T> get(int index){
        Node<T> res=head;
        while(res!=null){
            if(index==0) return res;
            res=res.next;
            index--;
        }
        return null;
    }
    public int getSize(){
        return size;
    }
    public void start () {
        current = head;
    }
    public void next () {
        current = current.next;
    }
    public boolean end(){ return current == null;}
    public boolean empty(){ return head==null;}
    public T getData() { return current.data;}
}
