package com.basma;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;


public class WordAnalysis_ADT {
    public int uniqueSize;
    public int allSize;
    public WordInformation[] sortedWords;
    public LinkedList<WordInformation>[] differentLengthsWords;

    public WordAnalysis_ADT(String fileName) throws FileNotFoundException {
        readFileAndAnalyse(fileName);
    }

    public void readFileAndAnalyse(String fileName) throws FileNotFoundException {
        int k=0;
        int row=1,col=0;
        String allWords="";
        try {
            File myFile = new File(fileName);
            Scanner reader = new Scanner(myFile);
            while (reader.hasNextLine()){
                String line = reader.nextLine();
                line = line.replace("\\n",System.lineSeparator());
                line = line.replace("“", "");
                line = line.replace("”", "");
                String[] lineWords = line.replaceAll("[\\p{Punct}&&[^_-]]+","").split("\\s");
                for(String newWord : lineWords){
                    if(newWord.isEmpty()) {
                        allWords+=System.lineSeparator();
                        continue;
                    }
                    allSize++;
                    k = Math.max(k, newWord.length());
                    allWords += newWord + " ";
                }
                allWords+=System.lineSeparator();
            }
            if(allSize==0) {
                System.err.println("File is Empty");
                System.exit(0);
                return;
            }

            sortedWords = new WordInformation[allSize];
            differentLengthsWords = new LinkedList[k + 1];
            int len = differentLengthsWords.length-1;
            while(len >-1){
                differentLengthsWords[len--] = new LinkedList<WordInformation>();
            }
            String [] allLinesWords = allWords.split(" ");

            for (String allLinesWord : allLinesWords) {
                String newWord = allLinesWord;
                if (newWord.contains("\n")) {
                    newWord = newWord.substring(1);
                    row++;
                    col = 0;
                    if (newWord.isEmpty()) continue;
                }
                col++;
                boolean flag = true;
                differentLengthsWords[newWord.length()].start();
                while (!differentLengthsWords[newWord.length()].end()) {
                    if (differentLengthsWords[newWord.length()].getData().word.equals(newWord)) {
                        differentLengthsWords[newWord.length()].getData().loc.insert(new WordOccurrence(row, col));
                        differentLengthsWords[newWord.length()].getData().size++;
                        flag = false;
                        break;
                    }
                    differentLengthsWords[newWord.length()].next();
                }
                if (flag) {
                    differentLengthsWords[newWord.length()].insert(new WordInformation(newWord, row, col));
                }
            }
            for (LinkedList<WordInformation> differentLength : differentLengthsWords) {
                differentLength.start();
                while (!differentLength.end()) {
                    sortedWords[uniqueSize++] = differentLength.getData();
                    differentLength.next();
                }
            }
            sort(sortedWords,0, uniqueSize -1);
        }
        catch (Exception e){
            System.err.println("File Not Found");
            throw e;
        }
    }

    // operation 1 O(1)
    public int documentLength(){ return allSize;}

    // operation 2 O(1)
    public int uniqueWords(){
        return uniqueSize;
    }

    // case 1 O(m/k)
    // case 2 O(m) If there is no repeated word then (n==m)
    public int totalWord (String targetWord){
        if(targetWord == null) {
            return 0;
        }
        differentLengthsWords[targetWord.length()].start();
        while(!differentLengthsWords[targetWord.length()].end()){
            if(targetWord.equals(differentLengthsWords[targetWord.length()].getData().word)){
                return differentLengthsWords[targetWord.length()].getData().size;
            }
            differentLengthsWords[targetWord.length()].next();
        }
        return 0;
    }

    // for all cases O(1)
    public int totalWordsForLength (int length){
        if(length>= differentLengthsWords.length || length<=0){
            System.out.println("Invalid length");
            return 0;
        }
        return differentLengthsWords[length].getSize();
    }

    // operation 5 O(m) If there is no repeated word then (n==m)
    public void displayUniqueWords (){
            int index=0;
            while(index< uniqueSize){
                System.out.print("("+ sortedWords[index].word+", "+ sortedWords[index].size +")");
                if(index!= uniqueSize -1) System.out.println(",");
                index++;
            }
            System.out.println();
    }

    // operation 6 O(m) If there is no repeated word then (n==m)
    public LinkedList<WordOccurrence> occurrences (String targetWord){
        LinkedList<WordOccurrence> res = null;
            if (targetWord !=null){
                int index = 0;
                while (index < uniqueSize) {
                    WordInformation tmpWord = sortedWords[index];
                    if (tmpWord.word.equals(targetWord)) {
                        res = tmpWord.loc;
                        break;
                    }
                    index++;
                }
            }
        return res;
        }

    // operation 7 O(n)
    public boolean checkAdjacent (String word1,String word2){
        if(word1 == null || word2==null) {
            return false;
        }
        LinkedList<WordOccurrence> wordOcc1 = null;
        LinkedList<WordOccurrence> wordOcc2 = null;
        int index=0;
        while(index< uniqueSize){
            WordInformation tmpWord = sortedWords[index];
            if(tmpWord.word.equals(word1)){
                wordOcc1 = new LinkedList<>(tmpWord.loc);
            }
            if(tmpWord.word.equals(word2)){
                wordOcc2 = new LinkedList<>(tmpWord.loc);
            }
            index++;
        }
        if(wordOcc1 ==null){
            System.out.println("Word ("+word1+") Not Found");
            return false;
        }
        if(wordOcc2 ==null){
            System.out.println("Word ("+word2+") Not Found");
            return false;
        }
        int loc1=0,loc2=0;
        while(loc1< wordOcc1.getSize() && loc2< wordOcc2.getSize()){
            if(wordOcc1.get(loc1).data.lineNo == wordOcc2.get(loc2).data.lineNo) {
                if(Math.abs(wordOcc1.get(loc1).data.position - wordOcc2.get(loc2).data.position) == 1){
                    return true;
                }
                else if(wordOcc1.get(loc1).data.position > wordOcc2.get(loc2).data.position){
                    loc2++;
                }
                else {
                    loc1++;
                }
            }
            else if(wordOcc1.get(loc1).data.lineNo > wordOcc2.get(loc2).data.lineNo){
                loc2++;
            }
            else{
                loc1++;
            }
        }
        return false;
    }

    public void merge(WordInformation[]arr, int l, int m, int r)
    {
        int n1 = m - l + 1;
        int n2 = r - m;
        WordInformation[]L = new WordInformation[n1];
        WordInformation[]R = new WordInformation[n2];

        System.arraycopy(arr, l, L, 0, n1);
        for (int j=0; j<n2; ++j)
            R[j] = arr[m + 1+ j];

        int i = 0, j = 0;
        int k = l;
        while (i < n1 && j < n2)
        {
            if (  L[i].size >= R[j].size )
            {
                arr[k] = L[i];
                i++;
            }
            else
            {
                arr[k] = R[j];
                j++;
            }
            k++;
        }

        while (i < n1)
        {
            arr[k] = L[i];
            i++;
            k++;
        }

        while (j < n2)
        {
            arr[k] = R[j];
            j++;
            k++;
        }
    }
    public void sort(WordInformation[]arr, int l, int r)
    {
        if (l < r)
        {
            int m = (l+r)/2;

            sort(arr, l, m);
            sort(arr , m+1, r);
            merge(arr, l, m, r);
        }
    }
}
