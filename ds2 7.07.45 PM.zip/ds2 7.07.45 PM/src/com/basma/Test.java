package com.basma;

public class Test {

    public static void main(String[] args) {
        try {
            WordAnalysis_ADT wa = new WordAnalysis_ADT("sample.txt");
            System.out.println("The output of operation (1) would be " + wa.documentLength ());
            System.out.println("The output of operation (2) would be "+ wa.uniqueWords ());
            System.out.println("The output of operation (3) for the word 'data' would be " + wa.totalWord ("data"));
            System.out.println("The output of operation (4) for word length 4 would be " + wa.totalWordsForLength (4));
            System.out.println("The output of operation (5) would be ");
            wa.displayUniqueWords ();
            System.out.print("The output of operation (6) for the word 'a' would be " );
            LinkedList<WordOccurrence> wo = wa.occurrences ("a");
            if(wo == null) {
                System.err.print("Word Not Found");
            }
            else{
                wo.start();
                while(!wo.end()){
                    System.out.print("(" + wo.getData().lineNo + ", " + wo.getData().position + ")  ");
                    wo.next();
                }
                System.out.println();
            }
            System.out.println("The output of operation (7) for the two words 'data' and 'A' would be " + wa.checkAdjacent ("data","A"));
        }
        catch (Exception e){
            System.out.println(e);
        }
    }
}
