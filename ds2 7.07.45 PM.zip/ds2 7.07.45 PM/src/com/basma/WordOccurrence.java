package com.basma;

public class WordOccurrence {
    public int lineNo;
    public int position;

    public WordOccurrence(int lineNo, int position) {
        this.lineNo = lineNo;
        this.position = position;
    }
}




